﻿using System;

namespace Task2
{
    public class NumberParser : INumberParser
    {
        public int Parse(string stringValue)
        {
            throw new NotImplementedException();
        }
    }
}